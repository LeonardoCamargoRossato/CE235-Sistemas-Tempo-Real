import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Para GitHub Pages em repositório de projeto, altere para "/NOME-DO-REPOSITORIO/".
  // Para domínio próprio ou <usuario>.github.io, mantenha "/".
  base: "/",
});

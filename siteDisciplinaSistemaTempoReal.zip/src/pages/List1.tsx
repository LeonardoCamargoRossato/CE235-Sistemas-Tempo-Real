import DriveCard from "../components/DriveCard";
import DriveFolderPreview from "../components/DriveFolderPreview";
import DriveFilePreview from "../components/DriveFilePreview";
import EvidenceGallery from "../components/EvidenceGallery";
import FileCard from "../components/FileCard";
import LabSection from "../components/LabSection";
import { getList } from "../data/lists";
import { links } from "../data/links";

const item = getList("list1");
const lab1 = item.files.slice(0,3), lab2 = item.files.slice(3);

export default function List1() {
  return <>
    <section className="page-header"><div className="container">
      <span className="eyebrow">CE-235 · LIST 1</span><h1>LIST 1</h1><h2>Modelagem e Simulação com ANSYS SCADE</h2>
    </div></section>
    <section className="section"><div className="container content-stack">
      <DriveCard title="Arquivos da List 1" description="Relatórios, projetos e artefatos dos Labs 1 e 2." href={links.list1Drive}/>

      <LabSection id="lab1" number="LAB 1" title="Landing Gear System" description="Desenvolvimento e simulação de um aplicativo de software de sistema embarcado de tempo real para controlar e representar os acionamentos do sistema de trem de pouso de uma aeronave fictícia utilizando ANSYS SCADE.">
        <h3>O que foi desenvolvido</h3>
        <ul className="compact-list"><li>Interface gráfica no SCADE Display.</li><li>Indicadores para nariz, lado esquerdo e lado direito.</li><li>Comandos Up/Down e Fail/Norm.</li><li>Lógica implementada no SCADE Suite.</li><li>Máquina de estados DOWN → TRANSITION → UP.</li><li>Temporização com ResetDelay.</li><li>Integração via propriedades ARINC 661.</li><li>Verificação e simulação do modelo.</li></ul>
        <div className="fact-grid"><div><b>Verde</b><span>posição estável</span></div><div><b>Âmbar</b><span>transição</span></div><div><b>Vermelho</b><span>falha</span></div></div>
        <p className="tech-line"><b>Ferramentas/conceitos:</b> ANSYS SCADE Suite · SCADE Display · ARINC 661 · State Machine · KCG · Simulator</p>

        <DriveFolderPreview title="Arquivos do Lab 1" description="Pasta oficial com LG.html, relatório, projeto compactado e demais materiais do Landing Gear."
          href={links.lab1Drive} embed={links.lab1Embed} buttonLabel="Abrir pasta do Lab 1 no Google Drive"/>

        <div className="files-grid">{lab1.map(f => <FileCard key={f.title} file={f} listLabel="LIST 1 · LAB 1" driveUrl={links.lab1Drive}/>)}</div>

        <div className="single-report-preview">
          <DriveFilePreview title="Relatório do Lab 1" fileName="RelatórioLab1_SistemasTempoReal_ITA_LeonardoRossato.pdf"
            description="Relatório do desenvolvimento e simulação do Landing Gear System utilizando ANSYS SCADE."
            fileId={links.lab1ReportPdfId} fallbackHref={links.lab1Drive} buttonLabel="Abrir PDF"/>
        </div>

        <div className="evidence-grid">
          <EvidenceGallery title="Evidências do Lab 1" folderHref={links.lab1EvidenceDrive} folderEmbed={links.lab1EvidenceEmbed}/>
          <EvidenceGallery title="Landing Gear — Evidências da Simulação" folderHref={links.landingGearEvidenceDrive} folderEmbed={links.landingGearEvidenceEmbed}/>
        </div>
      </LabSection>

      <LabSection id="lab2" number="LAB 2" title="Fuel Management System" description="Desenvolvimento e simulação de um aplicativo de gerenciamento de combustível integrando a lógica criada no ANSYS SCADE Suite com uma interface gráfica desenvolvida no SCADE Display.">
        <h3>Funcionalidades</h3>
        <ul className="compact-list"><li>Abrir e fechar o tanque; selecionar o tipo de combustível; controlar o reabastecimento.</li><li>Aumentar gradualmente o nível e esvaziar o tanque.</li><li>Representar graficamente nível e cor do combustível; indicar tanque cheio ou vazio.</li></ul>
        <h3>Implementação</h3>
        <p className="tech-line">Main · ShowLayer · SetFuelLevel · RepaintFuelLevel · SetFuelColor · SetFuelTankFullVisible · EnableWidgets</p>
        <div className="state-flow"><span>TankClosed</span><b>↕</b><span>TankOpen</span></div>
        <p className="prose">As entradas e saídas foram associadas aos eventos e propriedades dos componentes gráficos por meio do adaptador ARINC 661. O modelo foi verificado utilizando Check Model. Foram corrigidas incompatibilidades envolvendo bool, uint8, uint16, uint32 e as estruturas BoolMsg, IntMsg e IntMsg2.</p>

        <DriveFolderPreview title="Arquivos do Lab 2" description="Pasta oficial com relatório, projeto compactado e demais materiais do Fuel Management."
          href={links.lab2Drive} embed={links.lab2Embed} buttonLabel="Abrir pasta do Lab 2 no Google Drive"/>

        <div className="files-grid">{lab2.map(f => <FileCard key={f.title} file={f} listLabel="LIST 1 · LAB 2" driveUrl={links.lab2Drive}/>)}</div>

        <div className="single-report-preview">
          <DriveFilePreview title="Relatório do Lab 2" fileName="RelatórioLab2_SistemasTempoReal_ITA_LeonardoRossato.pdf"
            description="Relatório do desenvolvimento e simulação do Fuel Management utilizando ANSYS SCADE Suite e SCADE Display."
            fileId={links.lab2ReportPdfId} fallbackHref={links.lab2Drive} buttonLabel="Abrir PDF"/>
        </div>

        <EvidenceGallery title="Fuel Management — Evidências da Simulação" folderHref={links.lab2EvidenceDrive} folderEmbed={links.lab2EvidenceEmbed}/>
      </LabSection>
    </div></section>
  </>;
}

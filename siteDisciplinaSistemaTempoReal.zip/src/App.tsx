import { Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import Lists from "./pages/Lists";
import List0 from "./pages/List0";
import List1 from "./pages/List1";
import List2 from "./pages/List2";
import List3 from "./pages/List3";
import Artifacts from "./pages/Artifacts";
import FinalReport from "./pages/FinalReport";
import Scade from "./pages/Scade";
import NotFound from "./pages/NotFound";

export default function App() {
  return (
    <div className="app-shell">
      <ScrollToTop />
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/listas" element={<Lists />} />
          <Route path="/list0" element={<List0 />} />
          <Route path="/list1" element={<List1 />} />
          <Route path="/list2" element={<List2 />} />
          <Route path="/list3" element={<List3 />} />
          <Route path="/artefatos" element={<Artifacts />} />
          <Route path="/relatorio-final" element={<FinalReport />} />
          <Route path="/scade" element={<Scade />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

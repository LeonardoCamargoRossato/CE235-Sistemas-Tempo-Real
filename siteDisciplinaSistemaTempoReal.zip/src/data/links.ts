export const links = {
  disciplineDrive: "https://drive.google.com/drive/folders/1G2xcYjDR7YVyom-LLZlm7UlpJl-SgxsD",
  list0Drive: "https://drive.google.com/drive/folders/14sNp-xVnC_lFgO7Mn_b5Bk4OGMUQjB3o",
  list1Drive: "https://drive.google.com/drive/folders/1zHdXuhz86or6IIdm1uZ1rLUtkh5LBIbP",
  list2Drive: "https://drive.google.com/drive/folders/1MYAMwTjLNKQlQ_1_honnJ9yNXbsCWL7a",
  list3Drive: "https://drive.google.com/drive/folders/1XBxqqxhEtPH28rLyM3hbt0fQD92DiaQO",
  portfolio: "https://leonardocamargorossato.github.io/LCR-SolutionsArchitecture-IA-Quantum/#/",
  scadeOfficial: "https://www.ansys.com/products/embedded-software/ansys-scade-suite",
  finalReport: ""
} as const;
